<div class="container">
  <div class="head_wrapper">
    <div class="logo_box">
    	<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
			<p class="logo_title">ロゴ</p>
	  	</a>
    </div>
  </div>
</div>