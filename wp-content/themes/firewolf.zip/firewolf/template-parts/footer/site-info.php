<div class="foot_site_info">
	<p>ここにCopyrightがはいります</p>
</div><!-- .site-info -->
