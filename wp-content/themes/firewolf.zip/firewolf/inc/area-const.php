<?php

/**
 * key : field_5d389d45ffa88 ( not be able change )
 * name : chiiki (  be able change )
 * label : 地域の選択 (  be able change )
 */
    $chiiki_group_key = 'field_5d389d45ffa88';
    $chiiki_group = acf_get_field( $chiiki_group_key ); 
    $chiiki_group_name = $chiiki_group['name'];

/**
 * key : field_5d389d71ffa89 ( not be able change )
 * name : todofuken (  be able change )
 * label : 都道府県の選択 (  be able change )
 */
    $todofuken_group_key = 'field_5d389d71ffa89';
    $todofuken_group = acf_get_field( $todofuken_group_key );  
    $todofuken_group_name = $todofuken_group['name']; 

/**
 * key : field_5d390edea5c40 ( not be able change )
 * name : area (  be able change )
 * label : エリアの選択 (  be able change )
 */
    $eria_group_key = 'field_5d390edea5c40';
    $eria_group = acf_get_field( $eria_group_key );  
    $eria_group_name = $eria_group['name']; 

/**
 * key : field_5d39b36f27498 ( not be able change )
 * name : genre (  be able change )
 * label : エリアの選択 (  be able change )
 */
    $genre_group_key = 'field_5d39b36f27498';
    $genre_group = acf_get_field( $genre_group_key );  
    $genre_group_name = $eria_group['name']; 
