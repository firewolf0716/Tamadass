		<a href="#" class="scrollup">Top</a>

		<footer id="colophon" class="site_footer" role="contentinfo">	
			<div class="container">		
				<?php get_template_part( 'template-parts/footer/site', 'info' ); ?>
			</div>
		</footer><!-- #colophon -->
	</div><!-- .site-content-box -->
</div><!-- #page -->
<?php wp_footer(); ?>

</body>
</html>