jQuery(function($){

	// hamburger menu	
	resizer();
	$(window).on("resize",resizer);

	function resizer(){

		var headerHeight = $(".fixedHeader").outerHeight();

		var ww = window.innerWidth;

		if(ww > 640){
			$(".mv_title").css({
				"-webkit-transform": "skewX(-"+(0.012356*ww)+"deg)",
				"-ms-transform": "skewX(-"+(0.012356*ww)+"deg)",
				"transform": "skewX(-"+(0.012356*ww)+"deg)",
			});
			$(".mv_title p").css({
				"-webkit-transform": "skewX("+(0.012356*ww)+"deg)",
				"-ms-transform": "skewX("+(0.012356*ww)+"deg)",
				"transform": "skewX("+(0.012356*ww)+"deg)",
			});
		}
        if(ww <= 640){

			$("#hamburger_link").css({
				"top":headerHeight+"px",
			});

			$(".site-content-box").css({
				"margin-top":headerHeight+"px",
			});
		}
	}

});



	// hamburger menu	
	function hamburger() {
		var x = document.getElementById("hamburger_link");
		if (x.style.display === "block") {
			x.style.display = "none";
		} else {
			x.style.display = "block";
		}
	}