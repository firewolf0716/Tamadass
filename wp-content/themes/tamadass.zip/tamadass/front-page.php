<?php get_header(); 
	
	get_template_part( 'template-parts/front/main', 'visual' ); 
	get_template_part( 'template-parts/front/company', 'part' ); 
	get_template_part( 'template-parts/front/product', 'part' ); 
	get_template_part( 'template-parts/front/product', 'list' ); 
	get_template_part( 'template-parts/front/other', 'part' ); 
	get_template_part( 'template-parts/front/news', 'part' ); 

get_footer(); ?>
