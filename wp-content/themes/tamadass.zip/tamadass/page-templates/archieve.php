<?php
/**
 * Template Name: Archieve Page
 */
get_header(); ?>

<?php get_footer();