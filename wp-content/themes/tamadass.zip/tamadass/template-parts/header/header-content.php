<div class="headerWrapper">
	<div class="headerTop">
		<div class="fixedHeader border-b1">
			<div class="head_wrapper out_wrapper">	
				<div class="logo_box">
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
						<img src="<?=get_theme_file_uri( '/assets/img/logo.png' )?>" class="logo_img">
				  	</a>
				</div>
				<div class="head_menu_box pc">
					<?php if ( has_nav_menu( 'header' ) ) : ?>	
						<?php get_template_part( 'template-parts/navigation/navigation', 'header' ); ?>
					<?php endif; ?>
				</div>
				<div class="head_contact_box">
					<div class="head_tel">
						<a href="tel:0338352441" class="head_tel_num pc">
							<span>03-3835-2441</span>
						</a>
						<span class="head_tel_time pc">受付時間／月〜金 9:00〜18:00</span>
						<div class="sp sp_envelope">
							<img src="<?=get_theme_file_uri( '/assets/img/envelope.png' )?>">
						</div>
					</div>
					<div class="header_mail">
						<p class="pc">お問い合わせ</p>
						<div class="sp sp_phone">
							<a href="tel:0338352441" class="head_tel_num sp">
								<img src="<?=get_theme_file_uri( '/assets/img/phone.png' )?>">
							</a>
						</div>
					</div>
				</div>
				<div class="sp sp_menu">
					<div class="menuBtn menuBtnAction" onclick="hamburger()">
						<div class="menuBtnInner">
							<div></div>
							<div></div>
							<div></div>
						</div>
					</div>
				</div>
			</div>
		</div>		
		<div class="sp" id="hamburger_link">
			<?php wp_nav_menu( array(
			      'theme_location'=>'header',
			      'container'     =>'',
			      'menu_class'    =>'',
			      'items_wrap'    =>'<ul id="hamburger-nav" class="menu">%3$s</ul>'));
			?>
		</div>
	</div>
</div>

