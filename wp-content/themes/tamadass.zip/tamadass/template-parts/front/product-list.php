<div class="product_list_box">
	<div class="in_wrapper">
			
		<div class="pl_title_box">
			<div class="pl_title">
				<div class="left">
					<p>PETボトル</p>
				</div>
				<div class="right pc">
					<a href="#">
						<p>ペットボトル一覧</p>
					</a>
				</div>
			</div>
			<div class="pl_title_line"></div>
		</div>

		<div class="pl_list_box">
			<div class="pl_list_item">
				<div class="pll_item_title">
					<a href="#">
						<p>丸型容器</p>
					</a>
				</div>
				<div class="pll_item_figure">
					<img src="<?=get_theme_file_uri( '/assets/img/front/レイヤー 22 のコピー.jpg' )?>">
				</div>
			</div>
			<div class="pl_list_item">
				<div class="pll_item_title">
					<a href="#">
						<p>丸型容器</p>
					</a>
				</div>
				<div class="pll_item_figure">
					<img src="<?=get_theme_file_uri( '/assets/img/front/レイヤー 22 のコピー.jpg' )?>">
				</div>
			</div>
			<div class="pl_list_item">
				<div class="pll_item_title">
					<a href="#">
						<p>丸型容器</p>
					</a>
				</div>
				<div class="pll_item_figure">
					<img src="<?=get_theme_file_uri( '/assets/img/front/レイヤー 22 のコピー.jpg' )?>">
				</div>
			</div>
			<div class="pl_list_item">
				<div class="pll_item_title">
					<a href="#">
						<p>丸型容器</p>
					</a>
				</div>
				<div class="pll_item_figure">
					<img src="<?=get_theme_file_uri( '/assets/img/front/レイヤー 22 のコピー.jpg' )?>">
				</div>
			</div>
		</div>



	</div>
</div>