<div class="company_box">
	<div class="in_wrapper">
		<div class="company_label">
			<p>テキストテキストテキストテキスト</p>
			<p>テキストテキストテキストテキストテキスト</p>
		</div>
		<div class="company_description">
			<p>テキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキステキストテキストテキストテキストテキストテキストテキストテキス...</p>
		</div>
		<div class="company_btn pc">
			<a href="#" class="com_cha_btn">
		        <p>当社の特徴</p> 
		    </a>
		</div>
	</div>
	<img src="<?=get_theme_file_uri( '/assets/img/front/company_girl.jpg' )?>" class="company_girl pc">
</div>