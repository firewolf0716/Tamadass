
<div class="news_box">
	<div class="in_wrapper">
		<div class="news_top">
			<div class="news_title">
				<p class="news_title_top">NEWS</p>
				<p class="news_title_down">新着情報</p>
			</div>
			<div class="new_line"></div>
			<div class="news_list_box">
				<div class="news_list_item">
					<div class="news_date">
						<p>2019.01.01</p>
					</div>
					<div class="news_label">
						<p>NEWSタイトルNEWSタイトルNEWSタイトルNEWSタイトル</p>
					</div>
				</div>
				<div class="news_list_item">
					<div class="news_date">
						<p>2019.01.01</p>
					</div>
					<div class="news_label">
						<p>NEWSタイトルNEWSタイトルNEWSタイトルNEWSタイトル</p>
					</div>
				</div>
				<div class="news_list_item">
					<div class="news_date">
						<p>2019.01.01</p>
					</div>
					<div class="news_label">
						<p>NEWSタイトルNEWSタイトルNEWSタイトルNEWSタイトル</p>
					</div>
				</div>
				<div class="news_list_item">
					<div class="news_date">
						<p>2019.01.01</p>
					</div>
					<div class="news_label">
						<p>NEWSタイトルNEWSタイトルNEWSタイトルNEWSタイトル</p>
					</div>
				</div>
				<div class="news_list_item">
					<div class="news_date">
						<p>2019.01.01</p>
					</div>
					<div class="news_label">
						<p>NEWSタイトルNEWSタイトルNEWSタイトルNEWSタイトル</p>
					</div>
				</div>
			</div>
		</div>
		<div class="news_btn_box">
			<div class="news_btn pc">
				<a href="#" class="news_cha_btn">
			        <p>ニュース一覧を見る</p> 
			    </a>
			</div>
		</div>
	</div>
</div>