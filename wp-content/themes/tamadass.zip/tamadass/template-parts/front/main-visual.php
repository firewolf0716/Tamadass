
<div class="mvisual_box">
	<img src="<?=get_theme_file_uri( '/assets/img/front/mv_center.png' )?>">
	<div class="mv_title">
		<p>プラスチック容器・ペットボトルの企画・開発・製造、OEM のことなら<span>玉田製作所</span>へ</p>
	</div>
</div>