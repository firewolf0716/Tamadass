
<div class="other_box">
	<div class="in_wrapper">
		<div class="other_item_box about_box">
			<div class="other_kind">
				<p>ABOUT US</p>
			</div>
			<div class="other_title">
				<P>プラスチック容器の</P>
				<P>企画・開発・製造</P>
			</div>
		</div>
		<div class="other_item_box factory_box">
			<div class="other_kind">
				<p>FACTORY</p>
			</div>
			<div class="other_title">
				<P>工場設備</P>
			</div>
		</div>
		<div class="other_item_box molding_box">
			<div class="other_kind">
				<p>MOLDING FLOW</p>
			</div>
			<div class="other_title">
				<P>成形フロー</P>
			</div>
		</div>
	</div>
</div>