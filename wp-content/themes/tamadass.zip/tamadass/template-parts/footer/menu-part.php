<div class="in_wrapper">	
	<div class="foot_menu_wrapper pc">
		<?php if ( has_nav_menu( 'footer' ) ) : ?>	
			<?php get_template_part( 'template-parts/navigation/navigation', 'footer' ); ?>
		<?php endif; ?>
	</div>
	<div class="foot_site_info">
		<p>Copyright © TAMADA MANUFACTURING CO., LTD. All rights reserved.</p>
	</div><!-- .site-info -->
</div>
