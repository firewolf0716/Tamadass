		<footer id="colophon" class="site_footer" role="contentinfo">
			<div class="foot_logo_box">		
				<?php get_template_part( 'template-parts/footer/logo', 'part' ); ?>	
			</div>	
			<div class="foot_menu_box">
				<?php get_template_part( 'template-parts/footer/menu', 'part' ); ?>			
			</div>
		</footer><!-- #colophon -->
	</div><!-- .site-content-box -->
</div><!-- #page -->
<?php wp_footer(); ?>

</body>
</html>